﻿//Krisha Patel & Mj Mahida
//Madlib Part-1
//COM30S
//4th October 2022

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Madlib_Krisha_MJ
{
    class Madlib
    {
        public void title()
        {
            Console.Title = "Madlib Krisha & MJ";

            Console.WriteLine("^^^^^^^^^^");
            Console.WriteLine("  MADLIB  ");
            Console.WriteLine("^^^^^^^^^^");

            string title = @"
  _______ _                     _      _ _   _   _            
 |__   __| |                   | |    (_) | | | | |           
    | |  | |__  _ __ ___  ___  | |     _| |_| |_| | ___       
    | |  | '_ \| '__/ _ \/ _ \ | |    | | __| __| |/ _ \      
    | |  | | | | | |  __/  __/ | |____| | |_| |_| |  __/_ _ _ 
    |_|  |_| |_|_|  \___|\___| |______|_|\__|\__|_|\___(_|_|_)                                
                                                                 ";
            Console.WriteLine(title);
            Console.Write("Press enter to continue");
            Console.ReadLine();
        }

        public void playerInput()
        {
            string animal;
            string creature;
            string adj1;
            string adj2;
            string adj3;
            string adj4;
            string material1;
            string material2;
            string verb1;
            //string verb2;
            string story;

            Console.Write("\nEnter the main character (an animal) of the story: ");
            animal = Console.ReadLine();
            Console.Write("Enter an adjective for your animal: ");
            adj1 = Console.ReadLine();
            Console.Write("Enter another adjective for your animal: ");
            adj2 = Console.ReadLine();
            Console.Write("Enter an adjective for animal-1: ");
            adj3 = Console.ReadLine();
            Console.Write("Enter an adjective for animal-2: ");
            adj4 = Console.ReadLine();
            //Console.Write("Enter a verb for animal-1: ");
            //verb1 = Console.ReadLine();
            Console.Write("Enter a verb (in simple past tense) which relates to destroying stuff: ");
            verb1 = Console.ReadLine();
            Console.Write("Enter a material for animal-1: ");
            material1 = Console.ReadLine();
            Console.Write("Enter a material for animal-2: ");
            material2 = Console.ReadLine();
            Console.Write("Enter a scary creature: ");
            creature = Console.ReadLine();

            story = @"Once upon a time, there were three litle " + animal + "s. They were all really " + adj1 + ". One day their mother told them that they had to grow up and be more "
                + adj2 +". So all of them left to build their own houses. One "+ animal +" wanted to be really "+ adj3 +" so he built his house with "+ material1 +
                ". The second "+ animal +" was quite "+ adj4 +" so he built it with "+ material2 +". Finally, the third "+ animal +", knew the dangerous "+ creature +
                " lived nearby so he worked really hard to build his house. One day, the "+ creature +" came and knocked on the first "+ animal +"'s door and said, \"Let me in or I'll destroy your house.\" The "+ animal +" didn't open the door, so the "+ creature + " " + verb1 + " his house. Then off he went to the second " + animal + "'s house. He knocked on his door and said, \"Let me in or I'll destroy your house.\" The " + animal + " didn't let him in too, so the " + creature + " " + verb1 + " his house. After that he knocked on the third " + animal + "'s door and said \"Let me in or I'll destroy your house.\" The " + creature + " tried really hard to " + verb1 + " his house but failed every time. So at the end, all the three " + animal + "s ended up staying in the third "+ animal + "\'s house happily ever after.";
            Console.WriteLine(story);
            Console.ReadLine();
        }

        static void Main(string[] args)
        {
            Madlib m = new Madlib();
            m.title();
            m.playerInput();
        }
    }
}
